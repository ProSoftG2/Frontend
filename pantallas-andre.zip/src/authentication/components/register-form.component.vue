<script>
export default {
  name: "register-form",
  data() {
    return {
      firstName: '',
      lastName: '',
      email: '',
      phoneNumber: '',
      dni: '',
      password: ''
    };
  }
};
</script>

<template>
  <div class="container">
    <div class="half left">
      <div class="img-container">
        <img src="https://i.imgur.com/VuZwPb1.jpg" alt="Imagen" />
      </div>
    </div>
    <div class="half right">
      <div class="p-card p-shadow-2 p-mb-6" style="width: 80%;">
        <div class="p-card-body">
          <div class="p-text-center p-mb-5">
            <div class="p-text-bold p-font-size-xx-large">Welcome Back</div>
            <span class="p-font-weight-bold p-text-secondary">Don't have an account?</span>
            <a href="#" class="p-text-primary">Create today!</a>
          </div>
          <div class="p-fieldset p-grid p-nogutter">
            <div class="p-col-12 p-md-6">
              <h2 class="p-mb-4">Personal Information</h2>
              <p class="p-mb-4">Use a permanent address where you can receive mail.</p>
              <div class="p-formgroup-inline">
                <div class="p-field">
                  <label for="first-name">First name</label>
                  <pv-inputText v-model="firstName" id="first-name" class="p-inputtext-sm" />
                </div>
                <div class="p-field">
                  <label for="last-name">Last name</label>
                  <pv-inputText v-model="lastName" id="last-name" class="p-inputtext-sm" />
                </div>
                <div class="p-field">
                  <label for="phone-number">Phone number</label>
                  <pv-inputText v-model="phoneNumber" id="phone-number" class="p-inputtext-sm" />
                </div>
                <div class="p-field">
                  <label for="dni">DNI</label>
                  <pv-inputText v-model="dni" id="dni" class="p-inputtext-sm" />
                </div>
                <div class="p-field">
                  <label for="email">Email address</label>
                  <pv-inputText v-model="email" id="email" type="email" class="p-inputtext-sm" />
                </div>
                <div class="p-field">
                  <label for="password">Create password</label>
                  <pv-inputText v-model="password" id="password" class="p-inputtext-sm" />
                </div>
                <div class="p-field p-text-center">
                  <pv-button label="Register" class="p-button-sm p-button-primary" style="width: 100%;" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>


<style scoped>
.container {
  display: flex;
}

.half {
  flex: 1;
}

.left {
  background-color: #f0f0f0;
}

.right {
  display: flex;
  justify-content: center;
  align-items: center;
}

.img-container {
  max-width: 100%;
  max-height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: hidden;
}

.img-container img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.p-formgroup-inline .p-field {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  margin-bottom: 10px;
}

.p-formgroup-inline .p-field label {
  flex: 1;
  font-weight: bold;
}

.p-formgroup-inline .p-field .p-inputtext-sm {
  flex: 2;
}
.p-field {
  margin-bottom: 10px;
}
.p-button-sm {
  margin-top: 10px;
}
</style>