<script setup>
import RecoverPasswordForm from "../components/password-recovery-form.component.vue";
export default {
  name: "password-recovery",
  components: {PasswordRecoveryForm}
}
</script>

<template>
  <recover-password-form/>
</template>

<style scoped>

</style>