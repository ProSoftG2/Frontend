<script setup>
import PasswordForgotForm from "../components/password-forgot-form.component.vue";
export default {
  name: "password-forgot",
  components: {PasswordForgotForm}
}
</script>

<template>
  <password-forgot-form/>
</template>

<style scoped>

</style>