<script>
import RegisterForm from "../components/register-form.component.vue";
export default {
  name: "register",
  components: {RegisterForm}
}
</script>

<template>
  <register-form/>
</template>

<style scoped>

</style>