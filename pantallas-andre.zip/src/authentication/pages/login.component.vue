<script setup>
import LoginForm from "../components/login-form.component.vue";
export default {
  name: "login",
  components: {LoginForm}
}
</script>

<template>
  <login-form/>
</template>

<style scoped>

</style>